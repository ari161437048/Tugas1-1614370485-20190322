angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('pORTALAKADEMIK', {
    url: '/page8',
    templateUrl: 'templates/pORTALAKADEMIK.html',
    controller: 'pORTALAKADEMIKCtrl'
  })

  .state('pORTALAKADEMIK2', {
    url: '/page9',
    templateUrl: 'templates/pORTALAKADEMIK2.html',
    controller: 'pORTALAKADEMIK2Ctrl'
  })

  .state('hOME', {
    url: '/page10',
    templateUrl: 'templates/hOME.html',
    controller: 'hOMECtrl'
  })

  .state('mENUUTAMA', {
    url: '/page11',
    templateUrl: 'templates/mENUUTAMA.html',
    controller: 'mENUUTAMACtrl'
  })

  .state('jADWALMATAKULIAH', {
    url: '/page12',
    templateUrl: 'templates/jADWALMATAKULIAH.html',
    controller: 'jADWALMATAKULIAHCtrl'
  })

$urlRouterProvider.otherwise('/page8')


});